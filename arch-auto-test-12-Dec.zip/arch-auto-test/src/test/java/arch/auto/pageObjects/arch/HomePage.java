package arch.auto.pageObjects.arch;

import arch.auto.utils.selenium.DriverContext;
import arch.auto.utils.selenium.PageObjectUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.List;

public class HomePage extends PageObjectUtil {
    @FindBy(xpath="//a[@class='Header_nav_Primary']") private WebElement startMenuLink;
    @FindBy(xpath="//span[@class='menu-item-title' and text()='Search']") private WebElement searchMenuOption;
    @FindBy(xpath="//span[@class='menu-item-title' and text()='Create Submission']") private WebElement createSubmissionMenuOption;
    @FindBy(xpath = "(//a[@class='Header_nav'])[4]") private WebElement userMenuLink;
    @FindBy(xpath = "//span[@class='menu-item-title' and text()='Switch Application']/parent::span/parent::a") private WebElement switchApplicationOption;
    @FindBy(xpath="//span[@class='menu-item-title']") private List<WebElement> menuOptions;
    @FindBy(xpath = "//table[@id='RULE_KEY']/tbody/tr/td[2]/span") private WebElement caseIdTab;

    String menuOptionLink = "//span[@class='menu-item-title' and text()='?']/parent::span/parent::a";
    
    public HomePage() {initialise(this);}


    public void openStartMenu() {
        startMenuLink.click();
        waitPageToLoad();
    }

    public void openSearchfromStartMenu() {
        openStartMenu();
        waitUntilElementVisible(searchMenuOption);
        searchMenuOption.click();
        waitPageToLoad();
    }

    public void openCreateSubmissionfromStartMenu() {
        openStartMenu();
        waitUntilElementVisible(createSubmissionMenuOption);
        createSubmissionMenuOption.click();
        waitPageToLoad();
    }

    public void switchApplication(String applicationName) {
        userMenuLink.click();
        waitPageToLoad();
        waitUntilElementVisible(switchApplicationOption);
        moverToElement(switchApplicationOption);
        waitPageToLoad();
        WebElement appLink = findElement(By.xpath(menuOptionLink.replace("?", applicationName)));
        clickJS(appLink);
        waitPageToLoad();
        initialise(this);
        waitUntilElementClickable(startMenuLink);

    }

    public String getCaseId() {
        try {
            getDriver().switchTo().defaultContent();
        } catch (Exception ex) {
            // do nothing
        }
        return caseIdTab.getText().trim();
    }

}


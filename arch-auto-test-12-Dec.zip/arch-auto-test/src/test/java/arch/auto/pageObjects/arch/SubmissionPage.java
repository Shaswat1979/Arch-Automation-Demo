
package arch.auto.pageObjects.arch;

import arch.auto.utils.selenium.PageObjectUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SubmissionPage extends PageObjectUtil {

    public SubmissionPage() {
    	initialise(this);     
    }
	@FindBy(xpath = "//button[contains(text(), 'Search Insured Name')]") private WebElement searchInsuredNameBtn;
	@FindBy(xpath = "//div[contains(text(), 'Search Broker Details')]") private WebElement searchBrokerDetailsBtn;
	@FindBy(id = "NameCode") private WebElement nameSearchNameCodeTxtBox;
	@FindBy(xpath = "//button[contains(@name, 'NamesSearch_NamesSearchCriteriaPage')]") private WebElement searchInsuredNameDialogBoxBtn;
	@FindBy(xpath = "(//input[contains(@name, 'pShowManualEntry')])[2]") private WebElement showManulEntryInsuredName;
	@FindBy(id = "ModalButtonSubmit") private WebElement enterPartManuallyBtn;
	@FindBy(xpath = "//button[contains(text(), 'Select Party')]") private WebElement selectPartyBtn;
	@FindBy(xpath = "(//*[@id='LegalName'])[last()]") private WebElement legalNameTxtBox;
	@FindBy(xpath = "(//*[@id='Name'])[last()]") private WebElement listNameTxtBox;
	@FindBy(xpath = "(//*[@id='pyCity'])[last()]") private WebElement cityTxtBox;
	@FindBy(xpath = "(//*[@id='pyPostalCode'])[last()]") private WebElement postCodeTxtBox;
	@FindBy(xpath = "(//*[@id='AddressLine1'])[last()]") private WebElement addrLine1TxtBox;
	@FindBy(xpath = "(//*[@id='State'])[last()]") private WebElement stateSelectBox;
	@FindBy(id = "Designation") private WebElement designationSelectBox;
	@FindBy(id="USZone") private WebElement uwOfficeSelectBox;
	@FindBy(id="SubLOB1") private WebElement subLobSelectBox;
	@FindBy(id="CoverageGroupCode1") private WebElement productSelectBox;
	@FindBy(id="InceptionDate1") private WebElement inceptionDateBox;
	@FindBy(xpath = "(//button[contains(text(), 'Next')])[2]") private WebElement nextBottomBtn;
	@FindBy(xpath = "//div[text()='Complete Stage']") private WebElement completeStageBtn;
	@FindBy(xpath = "//button[contains(text(), 'Search Financials')]") private WebElement searchFinancialBtn;
	@FindBy(id = "DUNSSearchNumber") private WebElement dunsSearchNumber;
	@FindBy(xpath = "//button[contains(text(), 'Clear Search')]") private WebElement clearSearchBtn;
	@FindBy(xpath = "//button[text()='Search']") private WebElement searchBtn;
	@FindBy(xpath = "//button[contains(text(), 'Select Financials')]") private WebElement selectFinancialBtn;
	@FindBy(id = "SIC1") private WebElement sic1TxtField;
	@FindBy(id = "SIC2") private WebElement sic2TxtField;
	@FindBy(id = "SIC3") private WebElement sic3TxtField;
	@FindBy(xpath = "//button[text()='Add Location']") private WebElement addLocationBtn;
	@FindBy(id = "LocationNumber") private WebElement locationNumTxtField;
	@FindBy(id = "UniqueKey") private WebElement locationDescTxtField;
	@FindBy(id = "BuildingDescription") private WebElement buildingDescTxtField;
	@FindBy(id = "ModalButtonSubmit") private WebElement submitLocation;
	@FindBy(id = "pyStreet") private WebElement locationStreet;
	@FindBy(id = "pyCity") private WebElement locationCity;
	@FindBy(id = "pyState") private WebElement locationState;
	@FindBy(id = "pyNote") private WebElement selectLocation;


	@FindBy(xpath = "//button[contains(text(),'Add Other Named Insured')]") private WebElement addOtherNameInsuredBtn;
	@FindBy(id = "LegalName") private WebElement additionalNameInsuredNameFld;
	@FindBy(id = "ModalButtonSubmit") private WebElement additionalNameInsuredSumbitBtn;
//	@FindBy(id = "pyNote") private WebElement selectLocation;
	@FindBy(xpath = "(//input[@id='pyEmail1'])[4]") private WebElement uwEmail1;
	@FindBy(xpath = "(//input[@id='pyEmail1'])[6]") private WebElement uwOperations;

	@FindBy(xpath = "//button[text()='+ Add Insured Contact']") private WebElement addInsuredContactBtn;
	@FindBy(xpath = "//input[@id='Name1' and contains(@name,'pAdditionalInsuredPartyList')]") private WebElement addInsuredContactName;
	@FindBy(xpath = "//button[text()='+ Add Care of Contact']") private WebElement addCareOfContactContactBtn;
	@FindBy(xpath = "//input[@id='Name1' and contains(@name,'pCareOfNamesInsuredList')]") private WebElement addCareOfContactName;
	@FindBy(xpath = "//input[@id='AddressLine11' and contains(@name,'pCareOfNamesInsuredList')]") private WebElement addCareOfContactAddr;
	@FindBy(xpath = "//input[@id='pyCity1' and contains(@name,'pCareOfNamesInsuredList')]") private WebElement addCareOfContactCity;
	@FindBy(xpath = "//input[@id='pyPostalCode1' and contains(@name,'pCareOfNamesInsuredList')]") private WebElement addCareOfContactPostcode;
	@FindBy(xpath = "//select[@id='State1' and contains(@name,'pCareOfNamesInsuredList')]") private WebElement addCareOfContactState;

	@FindBy(xpath = "//button[text()='+ Add Broker Contact']") private WebElement addBrokerContactBtn;
	@FindBy(xpath = "//input[@id='Name1' and contains(@name,'pBrokerContactList')]") private WebElement addBrokerContactName;
	@FindBy(xpath = "//input[@id='pyPhoneNumber1' and contains(@name,'pBrokerContactList')]") private WebElement addBrokerContactNumber;
	@FindBy(xpath = "//input[@id='pyEmail11' and contains(@name,'pBrokerContactList')]") private WebElement addBrokerContactEmail;

	@FindBy(xpath = "//button[text()='+ Add Additional Contact']") private WebElement addAdditionalContactBtn;
	@FindBy(xpath = "//input[@id='Name1' and contains(@name,'pAdditionalContactList')]") private WebElement addAdditionalContactName;


	String InsuredSearchResult = "//tr/td/div/span[contains(text(), '?')]";
	String financialDunsSearchResult = "//tr/td/div/span[text()='?']";
	String sicSearchResult = "//tr[contains(@data-gargs,'?')]/td";
	String locationSelectResult ="(//tr/td/div/span[contains(text(),'?')]/parent::div/parent::td)[2]";

	public void searchInsuredName(String insuredName) {
		getDriver().switchTo().frame("PegaGadget0Ifr");
		waitPageToLoad();
		waitUntilElementClickable(searchInsuredNameBtn);
		sleep(5000L);
		searchInsuredNameBtn.click();

		//TODO: Search flow
		nameSearchNameCodeTxtBox.clear();
		nameSearchNameCodeTxtBox.sendKeys(insuredName);
		searchInsuredNameDialogBoxBtn.click();
		waitPageToLoad();
		findElement(By.xpath(InsuredSearchResult.replace("?", insuredName))).click();
		waitPageToLoad();
		scroll(selectPartyBtn);
		waitUntilElementClickable(selectPartyBtn);
		selectPartyBtn.click();
		waitPageToLoad();
		initialise(this);

//		waitUntilElementClickable(showManulEntryInsuredName);
//		showManulEntryInsuredName.click();
//		waitPageToLoad();
//		waitUntilElementVisibleAndClickable(enterPartManuallyBtn);
//		enterPartManuallyBtn.click();
//		waitPageToLoad();

//		//enter details manually till search flow is fixed
//		waitPageToLoad();
//		waitUntilElementVisible(legalNameTxtBox);
//		legalNameTxtBox.clear();
//		legalNameTxtBox.sendKeys("AAA AUTO TRANSPORT INC");
//		listNameTxtBox.clear();
//		listNameTxtBox.sendKeys("AAA AUTO TRANSPORT INC");
//		addrLine1TxtBox.clear();
//		addrLine1TxtBox.sendKeys("5654 MUIRFIELD VILLAGE CIRLCE");
//		cityTxtBox.clear();
//		cityTxtBox.sendKeys("LAKEWORTH");
//		postCodeTxtBox.clear();
//		postCodeTxtBox.sendKeys("33463");
		initialise(this);
		waitPageToLoad();
		waitUntilElementClickable(stateSelectBox);
		Select stateSelect = new Select(stateSelectBox);
		stateSelect.selectByVisibleText("Florida");
	}

	public void searchBrokerName(String brokerName, String brokerDesignation) {
		waitPageToLoad();
//		waitUntilElementClickable(searchBrokerDetailsBtn);
		sleep(5000L);
		searchBrokerDetailsBtn.click();

		//TODO: Search flow
		nameSearchNameCodeTxtBox.clear();
		nameSearchNameCodeTxtBox.sendKeys(brokerName);
		searchInsuredNameDialogBoxBtn.click();
		waitPageToLoad();
		findElement(By.xpath(InsuredSearchResult.replace("?", brokerName))).click();
		waitPageToLoad();
		scroll(selectPartyBtn);
		waitUntilElementClickable(selectPartyBtn);
		selectPartyBtn.click();
		waitPageToLoad();
		initialise(this);

//		waitUntilElementClickable(showManulEntryInsuredName);
//		showManulEntryInsuredName.click();
//		waitPageToLoad();
//		waitUntilElementVisibleAndClickable(enterPartManuallyBtn);
//		enterPartManuallyBtn.click();
//		waitPageToLoad();

//		//enter details manually till search flow is fixed
//		waitPageToLoad();
//		waitUntilElementVisibleAndClickable(legalNameTxtBox);
//		legalNameTxtBox.clear();
//		legalNameTxtBox.sendKeys("AAOM/D.L. Williams Insurance, Inc.");
//		listNameTxtBox.clear();
//		listNameTxtBox.sendKeys("US-AAOM/D.L. Wil Missoula");
//		addrLine1TxtBox.clear();
//		addrLine1TxtBox.sendKeys("223 E Main St");
//		cityTxtBox.clear();
//		cityTxtBox.sendKeys("Missoula");
//		postCodeTxtBox.clear();
//		postCodeTxtBox.sendKeys("59802");

		waitUntilElementClickable(designationSelectBox);
		Select designationSelect = new Select(designationSelectBox);
		designationSelect.selectByVisibleText(brokerDesignation);
		Select stateSelect = new Select(stateSelectBox);
		stateSelect.selectByVisibleText("Florida");
		System.out.println("---");
	}

	public void selectUnderwritingOffice(String uwOffice) {
		Select uwOfficeSelect = new Select(uwOfficeSelectBox);
		uwOfficeSelect.selectByVisibleText(uwOffice);
	}

	public void enterSubmissionDetails(String subLob, String product) {
		Select subLobSelect = new Select(subLobSelectBox);
		subLobSelect.selectByVisibleText(subLob);
		waitPageToLoad();
		sleep(5000L);
		initialise(this);
		waitUntilElementVisibleAndClickable(productSelectBox);
		Select productSelect = new Select(productSelectBox);
		productSelect.selectByVisibleText(product);
		waitPageToLoad();
		DateTimeFormatter df = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDateTime now = LocalDateTime.now();
		sleep(5000L);
		initialise(this);
		waitUntilElementClickable(inceptionDateBox);
		waitPageToLoad();
		String inceptionDateVal = df.format(now);
		inceptionDateBox.clear();
		inceptionDateBox.sendKeys(inceptionDateVal);
		inceptionDateBox.sendKeys(Keys.ENTER);
		waitPageToLoad();
		sleep(5000L);
		System.out.println("--");
	}

	public void proceedToNext()
	{
		waitPageToLoad();
		moverToElement(nextBottomBtn);
		nextBottomBtn.click();
		initialise(this);
		waitPageToLoad();
	}

	public void completeStage()
	{
		waitPageToLoad();
		moverToElement(completeStageBtn);
		completeStageBtn.click();
		initialise(this);
		waitPageToLoad();
	}



	public void searchFinancials() {
		searchFinancialBtn.click();
		waitUntilElementClickable(clearSearchBtn);
		clearSearchBtn.click();
		waitPageToLoad();
		waitUntilElementClickable(dunsSearchNumber);
		dunsSearchNumber.sendKeys("119703695");
		searchBtn.click();
		waitPageToLoad();
		findElement(By.xpath(financialDunsSearchResult.replace("?", "119703695"))).click();
		waitPageToLoad();
		scroll(selectFinancialBtn);
		waitUntilElementClickable(selectFinancialBtn);
		selectFinancialBtn.click();
	}

	public void enterSic2(String sic2Val) {
		initialise(this);
		waitPageToLoad();
		waitUntilElementClickable(sic2TxtField);
		scroll(sic2TxtField);
		sic2TxtField.clear();
		initialise(this);
		waitPageToLoad();
		sic2TxtField.sendKeys("3999");
//		findElement(By.xpath(sicSearchResult.replace("?", "3999"))).click();
		clickJS(findElement(By.xpath(sicSearchResult.replace("?", "3999"))));
		initialise(this);
		waitPageToLoad();
	}


	public void enterSic1(String sic1Val) {
		initialise(this);
		waitPageToLoad();
		waitUntilElementClickable(sic1TxtField);
		initialise(this);
		waitPageToLoad();
		scroll(sic1TxtField);
		sic1TxtField.clear();
		sleep(5000L);
		initialise(this);
		waitPageToLoad();
		sic1TxtField.sendKeys("7999");
//		findElement(By.xpath(sicSearchResult.replace("?", "3999"))).click();
		clickJS(findElement(By.xpath(sicSearchResult.replace("?", "7999"))));
		waitPageToLoad();
	}

	public void enterSic3(String sic3Val) {
		initialise(this);
		waitPageToLoad();
		sic3TxtField.clear();
		initialise(this);
		waitPageToLoad();
		sic3TxtField.sendKeys("5999");
//		findElement(By.xpath(sicSearchResult.replace("?", "5999"))).click();
		clickJS(findElement(By.xpath(sicSearchResult.replace("?", "5999"))));
		initialise(this);
		waitPageToLoad();
	}

	public void addAndSelectLocation() {
		waitPageToLoad();
		initialise(this);
		addLocationBtn.click();
		waitPageToLoad();
		waitUntilElementVisible(locationNumTxtField);
		initialise(this);
		locationNumTxtField.clear();
		locationNumTxtField.sendKeys("1");
		locationDescTxtField.sendKeys("4");
		buildingDescTxtField.sendKeys("test");
		scroll(locationCity);
		locationStreet.clear();
		locationStreet.sendKeys("6th main");
		waitPageToLoad();
		locationCity.clear();
		locationCity.sendKeys("nyc");
		waitPageToLoad();
		initialise(this);
		sleep(5000L);
		waitPageToLoad();
		waitUntilElementClickable(locationState);
		Select stateSelect = new Select(locationState);
		stateSelect.selectByVisibleText("Florida");
		waitPageToLoad();
		locationCity.clear();
		locationCity.sendKeys("nyc");
		waitPageToLoad();
		initialise(this);
		submitLocation.click();
		waitPageToLoad();
		initialise(this);
		waitUntilElementClickable(selectLocation);
		sleep(5000L);
		initialise(this);
		scroll(selectLocation);
		selectLocation.clear();
		waitPageToLoad();
		selectLocation.sendKeys("1");
//		waitPageToLoad();
		sleep(5000L);
		WebElement loc = findElement(By.xpath(locationSelectResult.replace("?", "6th")));
		System.out.println(loc.getText());
//		loc.click();
		clickJS(loc);
//		findElement(By.xpath(locationSelectResult.replace("?", "1"))).click();
//		clickJS(findElement(By.xpath(locationSelectResult.replace("?", "6th"))));
		sleep(2000L);
		waitPageToLoad();
		initialise(this);
	}

	public void addAdditionalNameInsured() {
//		scroll(addOtherNameInsuredBtn);
		waitUntilElementClickable(addOtherNameInsuredBtn);
		addOtherNameInsuredBtn.click();
		waitPageToLoad();
		waitUntilElementClickable(additionalNameInsuredNameFld);
		initialise(this);
		additionalNameInsuredNameFld.sendKeys("abc");
		additionalNameInsuredSumbitBtn.click();
		waitPageToLoad();
		initialise(this);
	}

	public void selectUnderwriterInfo() {
		uwEmail1.click();
		sleep(2000L);
		uwEmail1.sendKeys(Keys.ARROW_DOWN);
		sleep(2000L);
		uwEmail1.sendKeys(Keys.ARROW_DOWN);
		sleep(2000L);
		uwEmail1.sendKeys(Keys.ENTER);
		sleep(2000L);

		uwOperations.click();
		sleep(2000L);
		uwOperations.sendKeys(Keys.ARROW_DOWN);
		sleep(2000L);
		uwOperations.sendKeys(Keys.ARROW_DOWN);
		sleep(2000L);
		uwOperations.sendKeys(Keys.ENTER);
		sleep(2000L);
	}

	public void enterInsuredContactInfo() {
		addInsuredContactBtn.click();
		waitPageToLoad();
		waitUntilElementClickable(addInsuredContactName);
		initialise(this);
		addInsuredContactName.sendKeys("Test Test");
	}

	public void addCareOfContactInfo() {
		addCareOfContactContactBtn.click();
		waitPageToLoad();
		waitUntilElementClickable(addCareOfContactName);
		initialise(this);
		addCareOfContactName.sendKeys("Test CC");
		addCareOfContactAddr.sendKeys("4th Main Street");
		addCareOfContactCity.sendKeys("ndls");
		addCareOfContactPostcode.sendKeys("32003");
		Select stateSelect = new Select(addCareOfContactState);
		stateSelect.selectByVisibleText("Florida");
	}

	public void enterBrokerContactInfo() {
//		addBrokerContactBtn.click();
		waitUntilElementClickable(addBrokerContactName);
		initialise(this);
		addBrokerContactName.sendKeys("Test Broker");
		addBrokerContactNumber.sendKeys("34997");
		addBrokerContactEmail.sendKeys("test_broker@testarch.com");

	}

	public void addAdditionalContactInfo() {
		addAdditionalContactBtn.click();
		waitPageToLoad();
		waitUntilElementClickable(addAdditionalContactName);
		initialise(this);
		addAdditionalContactName.sendKeys("Test Additional");
	}
}


